import cv2
img = cv2.imread(r'C:\Users\nakul\OneDrive\Desktop\Ai_project\images\0282.png')
cv2.imshow('output', img)
cv2.waitKey(0)